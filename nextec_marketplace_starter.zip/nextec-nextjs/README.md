# Nextec marketplace — setup guide

This is a starter ecommerce app using Next.js, Supabase Auth/Postgres, and Stripe Checkout. It is a working project scaffold, not a finished, audited production store. It uses a server-side checkout route and reads prices from the database so browser-supplied prices are not trusted.

## Before you begin

You will need accounts at:
- Node.js (install the current LTS version): https://nodejs.org/
- Supabase: https://supabase.com/
- Stripe: https://stripe.com/
- Vercel: https://vercel.com/

A parent/guardian or authorized adult should help create and manage payment-provider and business accounts if required by the providers' age and account rules. Never share secret keys in chat or publish them in source code.

## 1. Run it on your computer

1. Install Node.js LTS.
2. Extract this ZIP.
3. Open the extracted `nextec-nextjs` folder in VS Code.
4. Open Terminal in VS Code and run `npm install`.
5. Copy `.env.example` to a new file named `.env.local`.
6. Fill in the Supabase and Stripe values described below.
7. Run `npm run dev`.
8. Visit http://localhost:3000

## 2. Create the Supabase database and authentication

1. Create a Supabase project at https://supabase.com/.
2. In Project Settings > API, copy the Project URL and anon/public key into `.env.local`.
3. Open SQL Editor in Supabase.
4. Paste and run all of `supabase/schema.sql`.
5. In Authentication > Providers, ensure Email is enabled.
6. In Authentication > URL Configuration, add your local URL `http://localhost:3000` for local testing. Add your final production domain later.
7. Create an account through the Nextec site.
8. In Authentication > Users, copy the new user's UUID.
9. In SQL Editor, grant admin access to that exact user:
   `insert into public.admin_users (user_id) values ('PASTE-USER-UUID-HERE');`
10. Sign out and sign in again if necessary. The Admin dashboard control appears for signed-in users; actual database writes are still protected by row-level security. If you see the dashboard but product changes fail, confirm that the logged-in user's UUID is in `admin_users`.

Never put `SUPABASE_SERVICE_ROLE_KEY` in a `NEXT_PUBLIC_` variable. It must remain server-only.

## 3. Configure Stripe test payments

1. Create or access a Stripe account at https://stripe.com/.
2. Start in Test mode.
3. In Stripe Developers > API keys, copy the **test secret key** (starts with `sk_test_`) into `.env.local` as `STRIPE_SECRET_KEY`.
4. Set `NEXT_PUBLIC_SITE_URL=http://localhost:3000`.
5. Restart the dev server after changing environment variables.
6. Add a product to your cart and press Secure checkout. Stripe Checkout should open.
7. Use a Stripe-provided test card from Stripe's official testing documentation. Do not use a real card while in test mode.
8. Test successful, canceled, invalid and mobile checkout flows.

The success page is only a customer-facing return page. Do not fulfill orders based only on a browser redirect. Before accepting real payments, implement a verified Stripe webhook that checks `checkout.session.completed`, records the order in a database, and handles refunds/failures. Add tax, shipping, inventory, order emails, privacy policy, terms, refund policy and customer support details appropriate for your business.

## 4. Publish to Vercel

1. Create a GitHub repository and upload the project files, or import the project folder using Vercel's supported workflow.
2. Visit https://vercel.com/ and choose Add New > Project.
3. Import your GitHub repository.
4. In project Settings > Environment Variables, add all values from `.env.local`:
   - `NEXT_PUBLIC_SUPABASE_URL`
   - `NEXT_PUBLIC_SUPABASE_ANON_KEY`
   - `SUPABASE_SERVICE_ROLE_KEY` (server-only)
   - `STRIPE_SECRET_KEY`
   - `NEXT_PUBLIC_SITE_URL` set to your final `https://...` domain
5. For the first deploy, use Stripe's test secret key.
6. Deploy and open the assigned Vercel URL.
7. Add that exact production URL to Supabase Authentication > URL Configuration.
8. Test sign-up/sign-in and test checkout on the deployed URL.
9. Only after completing the production checklist below should you switch to live Stripe keys.

## 5. Production checklist — do not skip

- [ ] Add a verified Stripe webhook and store orders server-side.
- [ ] Confirm products and prices are accurate and you have rights to sell/list them.
- [ ] Add shipping rates, tax handling, stock controls and order confirmation emails.
- [ ] Add privacy, terms, refund, shipping and contact pages.
- [ ] Add abuse/rate limiting and logging to checkout/admin endpoints.
- [ ] Confirm admin access is limited to the intended UUID(s).
- [ ] Test accessibility, mobile layout, failed payments, duplicate clicks and refunds.
- [ ] Use HTTPS and production keys only in server environment variables.
- [ ] Have a qualified adult/business owner review payment-provider eligibility and legal/tax requirements before launch.

## Current limitations

- Product imagery uses emoji placeholders; replace with licensed product photos and image storage.
- The cart is client-side and is not persisted across devices.
- User accounts use Supabase email/password authentication; password reset UX and email templates should be configured.
- There is no verified Stripe webhook/order history yet.
- Shipping, tax, inventory, discount codes, reviews and order emails are not implemented.
- Checkout currency is USD.
