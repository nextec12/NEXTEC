"use client";

import { useEffect, useMemo, useState } from "react";
import { supabase } from "@/lib/supabase";

type Product = { id: string; name: string; description: string; category: string; price_cents: number; image_emoji: string; active: boolean };
type CartLine = { product: Product; quantity: number };

export default function Home() {
  const [products, setProducts] = useState<Product[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState("");
  const [category, setCategory] = useState("All");
  const [cart, setCart] = useState<CartLine[]>([]);
  const [user, setUser] = useState<any>(null);
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [authMode, setAuthMode] = useState<"signin" | "signup">("signin");
  const [authOpen, setAuthOpen] = useState(false);
  const [notice, setNotice] = useState("");
  const [adminOpen, setAdminOpen] = useState(false);
  const [draft, setDraft] = useState({ name: "", description: "", category: "Electronics", price: "19.99", image_emoji: "📦" });
  const [busy, setBusy] = useState(false);

  async function loadProducts() {
    setLoading(true);
    const { data, error } = await supabase.from("products").select("*").eq("active", true).order("created_at", { ascending: false });
    if (error) setNotice("Could not load products. Check your Supabase setup.");
    setProducts((data || []) as Product[]);
    setLoading(false);
  }

  useEffect(() => {
    loadProducts();
    supabase.auth.getSession().then(({ data }) => setUser(data.session?.user ?? null));
    const { data: listener } = supabase.auth.onAuthStateChange((_event, session) => setUser(session?.user ?? null));
    return () => listener.subscription.unsubscribe();
  }, []);

  const categories = useMemo(() => ["All", ...Array.from(new Set(products.map(p => p.category)))], [products]);
  const visible = products.filter(p => (category === "All" || p.category === category) && `${p.name} ${p.description} ${p.category}`.toLowerCase().includes(search.toLowerCase()));
  const cartCount = cart.reduce((n, x) => n + x.quantity, 0);
  const total = cart.reduce((n, x) => n + x.product.price_cents * x.quantity, 0);

  function add(product: Product) {
    setCart(old => old.some(x => x.product.id === product.id)
      ? old.map(x => x.product.id === product.id ? { ...x, quantity: x.quantity + 1 } : x)
      : [...old, { product, quantity: 1 }]);
    setNotice(`${product.name} added to cart`);
  }
  function changeQty(id: string, quantity: number) {
    setCart(old => quantity < 1 ? old.filter(x => x.product.id !== id) : old.map(x => x.product.id === id ? { ...x, quantity } : x));
  }
  async function authSubmit(e: React.FormEvent) {
    e.preventDefault(); setBusy(true); setNotice("");
    const result = authMode === "signup"
      ? await supabase.auth.signUp({ email, password })
      : await supabase.auth.signInWithPassword({ email, password });
    setBusy(false);
    if (result.error) setNotice(result.error.message);
    else { setNotice(authMode === "signup" ? "Account created. Check your email if confirmation is enabled." : "Signed in successfully."); setAuthOpen(false); }
  }
  async function signOut() { await supabase.auth.signOut(); setNotice("Signed out."); setAdminOpen(false); }
  async function checkout() {
    if (!cart.length) return setNotice("Your cart is empty.");
    setBusy(true); setNotice("");
    try {
      const response = await fetch("/api/checkout", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ items: cart.map(x => ({ id: x.product.id, quantity: x.quantity })) }) });
      const body = await response.json();
      if (!response.ok) throw new Error(body.error || "Checkout failed.");
      window.location.href = body.url;
    } catch (err: any) { setNotice(err.message || "Could not start checkout."); setBusy(false); }
  }
  async function addProduct(e: React.FormEvent) {
    e.preventDefault();
    if (!user) return setNotice("Sign in with an admin account first.");
    setBusy(true);
    const { error } = await supabase.from("products").insert({
      name: draft.name, description: draft.description, category: draft.category,
      price_cents: Math.round(Number(draft.price) * 100), image_emoji: draft.image_emoji, active: true
    });
    setBusy(false);
    if (error) setNotice("Could not add product. Make sure this account has admin access.");
    else { setDraft({ name: "", description: "", category: "Electronics", price: "19.99", image_emoji: "📦" }); setNotice("Product added."); loadProducts(); }
  }
  async function deactivateProduct(id: string) {
    const { error } = await supabase.from("products").update({ active: false }).eq("id", id);
    setNotice(error ? "Could not remove product." : "Product hidden from the store.");
    if (!error) loadProducts();
  }

  return <main>
    <header className="topbar">
      <a className="brand" href="#"><span>nex</span>tec<span className="dot">.</span></a>
      <div className="welcome">Welcome to Nextec<strong>Shop smart today</strong></div>
      <form className="search" onSubmit={e => e.preventDefault()}><input value={search} onChange={e => setSearch(e.target.value)} placeholder="Search products, brands and more…" aria-label="Search products"/><button>Search</button></form>
      <button className="account" onClick={() => user ? setNotice(`Signed in as ${user.email}`) : setAuthOpen(true)}>{user ? "👤 My account" : "Hello, sign in"}<strong>{user ? user.email : "Account & lists"}</strong></button>
      {user && <button className="plain" onClick={signOut}>Sign out</button>}
      <button className="cartbutton" onClick={() => document.getElementById("cart")?.scrollIntoView({ behavior: "smooth" })}>🛒 Cart <b>{cartCount}</b></button>
    </header>
    <nav className="nav"><a href="#categories">☰ All departments</a><a href="#products">Today's picks</a><a href="#products">Best sellers</a><a href="#newsletter">Deals & offers</a>{user && <button onClick={() => setAdminOpen(!adminOpen)}>Admin dashboard</button>}</nav>

    <div className="wrap">
      <section className="hero"><div><p className="eyebrow">THE NEXTEC SHOPPING EXPERIENCE</p><h1>Good finds.<br/>Great prices.</h1><p>Discover tech, everyday essentials, home favorites and more—all in one easy place.</p><a className="cta" href="#products">Shop featured picks →</a></div><div className="heroIcon">🛍️</div></section>
      <section className="perks"><div>🚚 <span><b>Delivery options</b><small>Details at checkout</small></span></div><div>🔒 <span><b>Secure payments</b><small>Powered by Stripe Checkout</small></span></div><div>↩️ <span><b>Order support</b><small>Help when you need it</small></span></div><div>💬 <span><b>Customer care</b><small>We're here to help</small></span></div></section>

      {notice && <div className="notice" role="status"><span>{notice}</span><button onClick={() => setNotice("")}>×</button></div>}

      {adminOpen && user && <section className="admin panel">
        <div className="sectionHead"><div><h2>Admin dashboard</h2><p>Add new products or hide products from the storefront.</p></div><span className="pill">Admin access required</span></div>
        <form className="adminForm" onSubmit={addProduct}>
          <input required placeholder="Product name" value={draft.name} onChange={e => setDraft({...draft, name:e.target.value})}/>
          <input required placeholder="Description" value={draft.description} onChange={e => setDraft({...draft, description:e.target.value})}/>
          <select value={draft.category} onChange={e => setDraft({...draft, category:e.target.value})}><option>Electronics</option><option>Fashion</option><option>Home</option><option>Gaming</option><option>Beauty</option></select>
          <input required type="number" min="0.50" step="0.01" placeholder="Price" value={draft.price} onChange={e => setDraft({...draft, price:e.target.value})}/>
          <input required maxLength={8} placeholder="Emoji, e.g. 🎧" value={draft.image_emoji} onChange={e => setDraft({...draft, image_emoji:e.target.value})}/>
          <button className="primary" disabled={busy}>Add product</button>
        </form>
        <div className="adminList">{products.map(p => <div key={p.id}><span>{p.image_emoji} {p.name} · ${(p.price_cents/100).toFixed(2)}</span><button className="danger" onClick={() => deactivateProduct(p.id)}>Hide</button></div>)}</div>
        <p className="fine">Important: the database policies in the SQL setup restrict admin actions to users explicitly listed as admins. A visible button alone does not grant admin rights.</p>
      </section>}

      <section id="categories"><div className="sectionHead"><div><h2>Shop by category</h2><p>Find what you need, faster.</p></div></div><div className="categories" id="categoryList">{categories.map(c => <button key={c} className={`category ${category===c?"selected":""}`} onClick={() => setCategory(c)}><span>{({"All":"✨","Electronics":"🎧","Fashion":"👟","Home":"🏠","Gaming":"🎮","Beauty":"🧴"} as Record<string,string>)[c] || "📦"}</span><b>{c === "All" ? "All products" : c}</b></button>)}</div></section>

      <section id="products"><div className="sectionHead"><div><h2>{search ? `Search results (${visible.length})` : category === "All" ? "Featured picks" : `${category} picks`}</h2><p>Products available in the Nextec store.</p></div></div>
        {loading ? <div className="empty">Loading products…</div> : visible.length ? <div className="products">{visible.map(p => <article className="product" key={p.id}><div className="productArt"><span className="tag">NEXTEC PICK</span>{p.image_emoji || "📦"}</div><div className="productBody"><h3>{p.name}</h3><div className="stars">★★★★★ <small>Customer favorite</small></div><p>{p.description}</p><div className="price">${(p.price_cents/100).toFixed(2)}</div><button className="add" onClick={() => add(p)}>＋ Add to cart</button></div></article>)}</div> : <div className="empty">No products found. Add products in the admin dashboard or try another search.</div>}
      </section>

      <section id="cart" className="panel cartPanel"><div className="sectionHead"><div><h2>Your cart</h2><p>{cartCount} item(s) in your basket.</p></div></div>{cart.length ? <><div className="cartLines">{cart.map(line => <div className="cartLine" key={line.product.id}><span className="lineEmoji">{line.product.image_emoji}</span><div className="lineInfo"><b>{line.product.name}</b><small>${(line.product.price_cents/100).toFixed(2)} each</small></div><div className="quantity"><button onClick={() => changeQty(line.product.id,line.quantity-1)}>−</button><span>{line.quantity}</span><button onClick={() => changeQty(line.product.id,line.quantity+1)}>+</button></div><b>${(line.product.price_cents*line.quantity/100).toFixed(2)}</b></div>)}</div><div className="checkoutRow"><div><small>Subtotal (before shipping/tax)</small><strong>${(total/100).toFixed(2)}</strong></div><button className="primary" disabled={busy} onClick={checkout}>{busy ? "Please wait…" : "Secure checkout →"}</button></div><p className="fine">Checkout opens Stripe's secure payment page. Do not enter card details on this demo storefront.</p></> : <p className="empty">Your cart is empty. Add a product to get started.</p>}</section>

      <section id="newsletter" className="newsletter"><div><h2>Get the good deals first.</h2><p>Create an account to make shopping easier and stay connected.</p></div><button className="primary" onClick={() => {setAuthMode("signup");setAuthOpen(true)}}>Create account</button></section>
    </div>

    <footer><div><a className="brand footerBrand" href="#"><span>nex</span>tec<span className="dot">.</span></a><p>Your everyday marketplace.</p></div><div><b>Customer care</b><p>Help center · Shipping · Returns</p></div><div><b>About Nextec</b><p>Our story · Contact · Privacy</p></div><div>© 2026 Nextec. Add your business details before launch.</div></footer>

    {authOpen && <div className="modalBackdrop" onClick={() => setAuthOpen(false)}><section className="modal" onClick={e => e.stopPropagation()}><button className="close" onClick={() => setAuthOpen(false)}>×</button><h2>{authMode === "signin" ? "Sign in to Nextec" : "Create your account"}</h2><p>Use your email and a password to access your account.</p><form onSubmit={authSubmit}><label>Email address<input required type="email" autoComplete="email" value={email} onChange={e => setEmail(e.target.value)}/></label><label>Password<input required type="password" minLength={8} autoComplete={authMode === "signin" ? "current-password" : "new-password"} value={password} onChange={e => setPassword(e.target.value)}/></label><button className="primary" disabled={busy}>{busy ? "Please wait…" : authMode === "signin" ? "Sign in" : "Create account"}</button></form><p className="switchAuth">{authMode === "signin" ? "New to Nextec?" : "Already have an account?"} <button onClick={() => setAuthMode(authMode === "signin" ? "signup" : "signin")}>{authMode === "signin" ? "Create account" : "Sign in"}</button></p><small>Set your authentication and email confirmation settings in Supabase before launch.</small></section></div>}
  </main>;
}
