import Link from "next/link";

export default function Success() {
  return <main className="successPage"><div className="successCard"><div className="successIcon">✓</div><p className="eyebrow">NEXTEC CHECKOUT</p><h1>Thank you for your order!</h1><p>Stripe has returned you to the success page. In a production store, confirm payment and create the final order from a verified Stripe webhook before shipping anything.</p><Link className="cta" href="/">Continue shopping →</Link></div></main>;
}
