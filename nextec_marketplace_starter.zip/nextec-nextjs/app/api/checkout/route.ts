import { NextResponse } from "next/server";
import Stripe from "stripe";
import { createClient } from "@supabase/supabase-js";

export const runtime = "nodejs";

export async function POST(request: Request) {
  try {
    if (!process.env.STRIPE_SECRET_KEY) {
      return NextResponse.json({ error: "Stripe is not configured yet. Add STRIPE_SECRET_KEY to your deployment environment." }, { status: 503 });
    }
    const body = await request.json();
    const items = body.items;
    if (!Array.isArray(items) || items.length === 0 || items.length > 30) {
      return NextResponse.json({ error: "Your cart is empty or contains too many items." }, { status: 400 });
    }

    const normalized = new Map<string, number>();
    for (const item of items) {
      if (typeof item.id !== "string" || !Number.isInteger(item.quantity) || item.quantity < 1 || item.quantity > 20) {
        return NextResponse.json({ error: "Invalid cart item." }, { status: 400 });
      }
      normalized.set(item.id, (normalized.get(item.id) || 0) + item.quantity);
    }

    // The server looks up current prices from the database; it never trusts prices sent by the browser.
    const adminDb = createClient(
      process.env.NEXT_PUBLIC_SUPABASE_URL!,
      process.env.SUPABASE_SERVICE_ROLE_KEY!,
      { auth: { persistSession: false } }
    );
    const ids = [...normalized.keys()];
    const { data: products, error } = await adminDb.from("products").select("id,name,description,price_cents,active").in("id", ids);
    if (error || !products || products.length !== ids.length || products.some(p => !p.active || p.price_cents < 50)) {
      return NextResponse.json({ error: "One or more products are no longer available. Refresh your cart." }, { status: 400 });
    }

    const stripe = new Stripe(process.env.STRIPE_SECRET_KEY);
    const baseUrl = process.env.NEXT_PUBLIC_SITE_URL || new URL(request.url).origin;
    const session = await stripe.checkout.sessions.create({
      mode: "payment",
      line_items: products.map(p => ({
        quantity: normalized.get(p.id)!,
        price_data: {
          currency: "usd",
          unit_amount: p.price_cents,
          product_data: { name: p.name, description: p.description || undefined }
        }
      })),
      billing_address_collection: "auto",
      success_url: `${baseUrl}/success?session_id={CHECKOUT_SESSION_ID}`,
      cancel_url: `${baseUrl}/?checkout=cancelled#cart`,
      metadata: { product_ids: ids.join(",") }
    });
    return NextResponse.json({ url: session.url });
  } catch {
    return NextResponse.json({ error: "Unable to create checkout session. Check your server configuration." }, { status: 500 });
  }
}
