import type { Metadata } from "next";
import "./styles.css";

export const metadata: Metadata = {
  title: "Nextec | Shop smart",
  description: "Discover tech, home, fashion, gaming and everyday essentials at Nextec."
};

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return <html lang="en"><body>{children}</body></html>;
}
