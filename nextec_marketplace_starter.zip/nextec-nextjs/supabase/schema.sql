-- Run this entire file in Supabase Dashboard > SQL Editor.
create extension if not exists pgcrypto;

create table if not exists public.products (
  id uuid primary key default gen_random_uuid(),
  name text not null check (char_length(name) between 1 and 120),
  description text not null default '',
  category text not null default 'Other',
  price_cents integer not null check (price_cents >= 50),
  image_emoji text not null default '📦',
  active boolean not null default true,
  created_at timestamptz not null default now()
);

create table if not exists public.admin_users (
  user_id uuid primary key references auth.users(id) on delete cascade,
  created_at timestamptz not null default now()
);

alter table public.products enable row level security;
alter table public.admin_users enable row level security;

-- Anyone can read active storefront products; only admins can insert/update.
drop policy if exists "Public can view active products" on public.products;
create policy "Public can view active products" on public.products
  for select using (active = true or exists (
    select 1 from public.admin_users a where a.user_id = auth.uid()
  ));

drop policy if exists "Admins can insert products" on public.products;
create policy "Admins can insert products" on public.products
  for insert to authenticated with check (
    exists (select 1 from public.admin_users a where a.user_id = auth.uid())
  );

drop policy if exists "Admins can update products" on public.products;
create policy "Admins can update products" on public.products
  for update to authenticated using (
    exists (select 1 from public.admin_users a where a.user_id = auth.uid())
  ) with check (
    exists (select 1 from public.admin_users a where a.user_id = auth.uid())
  );

drop policy if exists "Admins can view admin list" on public.admin_users;
create policy "Admins can view admin list" on public.admin_users
  for select to authenticated using (user_id = auth.uid());

-- Starter products. Change names, descriptions and prices before your real launch.
insert into public.products (name, description, category, price_cents, image_emoji) values
('Wireless Headphones','Comfortable wireless sound for everyday listening.','Electronics',4999,'🎧'),
('Smart Watch','A sleek everyday watch concept.','Electronics',7999,'⌚'),
('Portable Bluetooth Speaker','Compact sound for your playlist on the go.','Electronics',3499,'🔊'),
('Everyday Backpack','A versatile bag for school, work and travel.','Fashion',2999,'🎒'),
('Classic Sneakers','A casual sneaker style for everyday outfits.','Fashion',5499,'👟'),
('Minimal Desk Lamp','A modern accent for your desk or nightstand.','Home',2499,'💡'),
('Insulated Water Bottle','A reusable bottle for days on the go.','Home',1899,'🥤'),
('Gaming Controller','A controller-inspired pick for your setup.','Gaming',3999,'🎮')
on conflict do nothing;

-- After you create your account in the app, copy its user UUID from
-- Supabase Dashboard > Authentication > Users, then run:
-- insert into public.admin_users (user_id) values ('PASTE-USER-UUID-HERE');
